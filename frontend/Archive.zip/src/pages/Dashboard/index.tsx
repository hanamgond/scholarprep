export default function DashboardPage() {
  return <h1 className="text-2xl font-bold">Dashboard</h1>;
}
