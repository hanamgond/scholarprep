export default function DepartmentsPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Departments</h1>
      <p className="text-gray-600">Departments catalog and ownership.</p>
    </div>
  );
}
