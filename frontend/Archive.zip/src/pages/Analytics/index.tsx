export default function AnalyticsPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Analytics</h1>
      <p className="text-gray-600">High-level insights for administration.</p>
    </div>
  );
}
