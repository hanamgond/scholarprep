export default function ResultsPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Results</h1>
      <p className="text-gray-600">List of exams/tests with detailed analytics.</p>
    </div>
  );
}
