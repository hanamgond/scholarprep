export default function AttendancePage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Attendance</h1>
      <p className="text-gray-600">Attendance tracking and reports.</p>
    </div>
  );
}
