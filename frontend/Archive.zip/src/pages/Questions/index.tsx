export default function QuestionsPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Questions</h1>
      <p className="text-gray-600">Coming soon: view, add, and bulk-upload questions.</p>
    </div>
  );
}
