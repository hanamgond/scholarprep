export default function StaffPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-2">Staff</h1>
      <p className="text-gray-600">Manage staff members and roles.</p>
    </div>
  );
}
