export default function ExamsPage() {
  return <h1 className="text-2xl font-bold">Exams</h1>;
}
